package com.aurora.player;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AuroraWidgetPlugin.class);
        registerPlugin(AuroraFilesPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
