package com.aurora.player;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Recibe los toques del widget. Si la app está viva le pasa la orden; si no, la abre. */
public class AuroraWidgetActionActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String a = getIntent() != null ? getIntent().getAction() : null;
        if (a != null && !AuroraWidgetPlugin.dispatch(a)) {
            getSharedPreferences(AuroraWidgetProvider.PREFS, 0).edit().putString("pending", a).apply();
            Intent open = new Intent(this, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            try {
                startActivity(open);
            } catch (Exception e) {
            }
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
