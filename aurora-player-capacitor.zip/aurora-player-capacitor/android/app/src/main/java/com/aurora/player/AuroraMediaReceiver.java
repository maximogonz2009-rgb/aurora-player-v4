package com.aurora.player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Botones de la notificación de reproducción. */
public class AuroraMediaReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i != null && i.getAction() != null) AuroraWidgetPlugin.dispatch(i.getAction());
    }
}
