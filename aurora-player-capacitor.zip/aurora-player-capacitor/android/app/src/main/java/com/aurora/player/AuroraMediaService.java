package com.aurora.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;

/** Notificación de reproducción (la "nubecita") con controles y sesión multimedia. */
public class AuroraMediaService extends Service {
    static final String CH = "aurora_playback";
    static final int ID = 7;
    static final String A_STOP = "com.aurora.player.MEDIA_STOP";
    static volatile boolean running = false;
    private MediaSession session;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (session != null) {
            session.setActive(false);
            session.release();
            session = null;
        }
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && A_STOP.equals(i.getAction())) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            show(getSharedPreferences(AuroraWidgetProvider.PREFS, 0));
        } catch (Throwable t) {
            android.util.Log.e("AuroraMedia", "show failed", t);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private PendingIntent act(String action, int code) {
        Intent i = new Intent(this, AuroraMediaReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification.Action action(int res, String label, String a, int code) {
        return new Notification.Action.Builder(Icon.createWithResource(this, res), label, act(a, code)).build();
    }

    private void show(SharedPreferences p) {
        String title = p.getString("title", "Aurora Player");
        String artist = p.getString("artist", "");
        boolean playing = p.getBoolean("playing", false);
        Bitmap cover = null;
        String b64 = p.getString("cover", "");
        if (b64 != null && b64.length() > 0) {
            try {
                byte[] d = Base64.decode(b64, Base64.DEFAULT);
                cover = BitmapFactory.decodeByteArray(d, 0, d.length);
            } catch (Exception e) {
                cover = null;
            }
        }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Reproducción", NotificationManager.IMPORTANCE_LOW));
        }
        if (session == null) {
            session = new MediaSession(this, "AuroraPlayer");
            session.setCallback(new MediaSession.Callback() {
                @Override
                public void onPlay() {
                    AuroraWidgetPlugin.dispatch(AuroraWidgetProvider.A_PLAY);
                }

                @Override
                public void onPause() {
                    AuroraWidgetPlugin.dispatch(AuroraWidgetProvider.A_PLAY);
                }

                @Override
                public void onSkipToNext() {
                    AuroraWidgetPlugin.dispatch(AuroraWidgetProvider.A_NEXT);
                }

                @Override
                public void onSkipToPrevious() {
                    AuroraWidgetPlugin.dispatch(AuroraWidgetProvider.A_PREV);
                }
            });
        }
        MediaMetadata.Builder mb = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist);
        if (cover != null) mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, cover);
        session.setMetadata(mb.build());
        long acts = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        session.setPlaybackState(new PlaybackState.Builder().setActions(acts)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, playing ? 1f : 0f).build());
        session.setActive(true);

        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        nb.setSmallIcon(R.drawable.ic_stat_music)
                .setContentTitle(title)
                .setContentText(artist)
                .setContentIntent(content)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(playing)
                .addAction(action(R.drawable.w_ic_prev, "Anterior", AuroraWidgetProvider.A_PREV, 11))
                .addAction(action(playing ? R.drawable.w_ic_pause : R.drawable.w_ic_play, playing ? "Pausar" : "Reproducir", AuroraWidgetProvider.A_PLAY, 12))
                .addAction(action(R.drawable.w_ic_next, "Siguiente", AuroraWidgetProvider.A_NEXT, 13))
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        if (cover != null) nb.setLargeIcon(cover);
        Notification n = nb.build();
        if (playing) {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(ID, n);
        } else {
            stopForeground(false);
            nm.notify(ID, n);
        }
    }
}
