package com.aurora.player;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Puente entre la app web y el widget de la pantalla principal. */
@CapacitorPlugin(name = "AuroraWidget")
public class AuroraWidgetPlugin extends Plugin {
    private static AuroraWidgetPlugin inst;
    private static boolean asked = false;

    @Override
    public void load() {
        inst = this;
    }

    @Override
    protected void handleOnDestroy() {
        if (inst == this) inst = null;
    }

    /** Devuelve true si la app estaba viva y recibió la orden. */
    static boolean dispatch(String action) {
        AuroraWidgetPlugin p = inst;
        if (p == null) return false;
        JSObject o = new JSObject();
        o.put("action", action);
        p.notifyListeners("widgetAction", o);
        return true;
    }

    @PluginMethod
    public void pending(PluginCall call) {
        SharedPreferences sp = getContext().getSharedPreferences(AuroraWidgetProvider.PREFS, 0);
        JSObject o = new JSObject();
        o.put("action", sp.getString("pending", ""));
        sp.edit().remove("pending").apply();
        call.resolve(o);
    }

    @PluginMethod
    public void update(PluginCall call) {
        try {
            doUpdate(call);
        } catch (Throwable t) {
            android.util.Log.e("AuroraWidget", "update failed", t);
            call.reject(String.valueOf(t));
        }
    }

    private void doUpdate(PluginCall call) {
        SharedPreferences.Editor e = getContext().getSharedPreferences(AuroraWidgetProvider.PREFS, 0).edit();
        e.putString("title", call.getString("title", "Aurora Player"));
        e.putString("artist", call.getString("artist", ""));
        e.putBoolean("playing", Boolean.TRUE.equals(call.getBoolean("playing", false)));
        e.putString("color", call.getString("color", "#8b8cff"));
        e.putString("accent", call.getString("accent", "#8b8cff"));
        e.putString("fmt", call.getString("fmt", "cd"));
        e.putString("cover", call.getString("cover", ""));
        e.apply();
        AuroraWidgetProvider.refresh(getContext());
        syncMedia(Boolean.TRUE.equals(call.getBoolean("idle", false)), Boolean.TRUE.equals(call.getBoolean("playing", false)));
        call.resolve();
    }

    private void syncMedia(boolean idle, boolean playing) {
        final Context c = getContext();
        try {
            if (idle) {
                if (AuroraMediaService.running) c.startService(new Intent(c, AuroraMediaService.class).setAction(AuroraMediaService.A_STOP));
                return;
            }
            if (Build.VERSION.SDK_INT >= 33 && !asked && getActivity() != null
                    && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                asked = true;
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        getActivity().requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4242);
                    }
                });
            }
            Intent si = new Intent(c, AuroraMediaService.class);
            if (playing && Build.VERSION.SDK_INT >= 26) c.startForegroundService(si);
            else if (playing || AuroraMediaService.running) c.startService(si);
        } catch (Throwable t) {
            android.util.Log.e("AuroraWidget", "media sync failed", t);
        }
    }
}
