# Aurora Player — app para Android e iOS

Es el mismo reproductor que probaste en el HTML, envuelto con **Capacitor 8** para que sea una app instalable.
Toda la app vive en **`www/index.html`**. Si cambiás algo ahí, corrés `npx cap sync` y listo.

```
www/index.html     <- la app (HTML único)
android/           <- proyecto Android (Android Studio)
ios/               <- proyecto iOS (Xcode, Swift Package Manager, sin CocoaPods)
capacitor.config.json
.github/workflows/android.yml   <- compila el APK en GitHub
```

## Android

**Opción A: Android Studio** (2025.2.1 o más nuevo; trae su propio JDK)
```
npm install
npx cap open android      # sincroniza y abre el proyecto
```
Después tocá ▶ Run con el celular conectado (depuración USB activada).

**Opción B: sin instalar nada, APK desde GitHub**
1. Subí el contenido de esta carpeta a un repo de GitHub (rama `main`).
2. Entrá a *Actions → Android APK → Run workflow*.
3. Cuando termine, bajá el artefacto `aurora-player-apk`, descomprimilo e instalá `app-debug.apk`.

Si compilás por terminal con Gradle, usá **JDK 21** (Capacitor 8 no compila con 17 ni con 25).

## iOS (hace falta una Mac)
```
npm install
npx cap open ios
```
En Xcode 26 o más nuevo: elegí tu *Team* en *Signing & Capabilities* y dale ▶ con el iPhone conectado.
Con un Apple ID gratuito la app instalada dura 7 días; para publicarla en la App Store o usar TestFlight necesitás la cuenta de desarrollador paga.

## Qué cambia respecto al HTML
- Ícono de CD holográfico y pantalla de arranque oscura.
- Vibración al mantener apretado (háptica nativa).
- El color de la barra de estado cambia con el fondo elegido (Aurora, Negro, Blanco, Cromo).
- Pantalla vertical fija.
- El botón "Carpeta" se oculta (los móviles no lo soportan); se usa "Archivos".
- Música en segundo plano: iOS declara el modo de audio de fondo; en Android el WebView sigue activo al salir de la app.
- Los controles de la pantalla de bloqueo usan Media Session.

## Requisitos mínimos
iOS 16.4 o más · Android 7 (API 24) o más, con *Android System WebView* actualizado.

## Para probar primero en el celular
- Audio con la pantalla apagada (Android e iOS).
- Que los audios sigan ahí después de cerrar y reabrir la app.
- Si Android corta la música con la pantalla apagada, el paso siguiente es un servicio en primer plano con notificación de reproducción.

## Novedades v5
- Primer arranque: asistente para elegir fondo, color y primer disco. Sin discos ni audios de demostración.
- Disco "Biblioteca": todas tus canciones viven ahí; podés agregarlas a otros discos con el botón + o "Biblioteca".
- Sin límite de tamaño: manda el espacio libre del teléfono. Un WAV pesa ~10 MB por minuto; MP3/M4A unas 10 veces menos.
- Cambiar de disco no reproduce ni corta nada.
- Sin bordes en la interfaz.

## Actualizar la app
1. Subí el zip nuevo al repo (mismo nombre) para que GitHub genere un Release nuevo.
2. Bajá el APK e instalalo encima: los datos se conservan porque ahora la firma es fija.
   (El primer APK con esta firma requiere desinstalar la versión anterior una vez.)

## Spotify
No se pueden transferir playlists sin descargar: el audio de Spotify está protegido. Se importa la lista de temas (CSV/TXT/JSON/M3U) y se vincula con tus archivos locales por nombre.

## Novedades v6
- Los discos ahora son MiniDisc: carcasa translúcida, persiana metálica que se abre y disco con tu portada.
- Sin texto impreso en los discos. Aura holográfica opcional y fondo del disco (grafito, plata, negro) al apagarla.
- Inicio con botones fijos y un paso de tutorial (deslizar, tocar, mantener).
- Al volver al inicio no se precarga ninguna canción en el reproductor.
- Fondo cromo reactivo: el reflejo se mueve con el giro del celular o el dedo; el botón play es una esfera cromada.
- Bordes de la interfaz restaurados; la pantalla va de borde a borde.

## Novedades v7
- Vuelve el estuche de CD real (más detallado: marcos en las esquinas, bisagras, traba lateral) y la tapa se abre al abrir el disco.
- Disco estilo MiniDisc de color: elegís el color del disco y el color del vidrio del estuche. Aura holográfica opcional.
- Cromo igual al del Aurora Launcher: gris metálico suave que se mueve con el giro del celular.

## Novedades v8
- Fondo Aurora = glow desde arriba con color de fade a elección (Personalizar > General).
- Menú de personalización en pestañas: Disco / Música / General, con efectos plegados.

## Novedades v9
- Opciones de presentación (Personalizar > General): Clásico y Lateral (disco a la izquierda, lista a la derecha; tocar el disco = play/pausa).
- Fondo ambiente: la portada del disco (o su color) difuminada detrás de todo.
