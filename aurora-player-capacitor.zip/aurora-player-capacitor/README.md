# Aurora Player — app para Android e iOS

Es el mismo reproductor que probaste en el HTML, envuelto con **Capacitor 8** para que sea una app instalable.
Toda la app vive en **`www/index.html`**. Si cambiás algo ahí, corrés `npx cap sync` y listo.

```
www/index.html     <- la app (HTML único)
android/           <- proyecto Android (Android Studio)
ios/               <- proyecto iOS (Xcode, Swift Package Manager, sin CocoaPods)
capacitor.config.json
.github/workflows/android.yml   <- compila el APK en GitHub
```

## Android

**Opción A: Android Studio** (2025.2.1 o más nuevo; trae su propio JDK)
```
npm install
npx cap open android      # sincroniza y abre el proyecto
```
Después tocá ▶ Run con el celular conectado (depuración USB activada).

**Opción B: sin instalar nada, APK desde GitHub**
1. Subí el contenido de esta carpeta a un repo de GitHub (rama `main`).
2. Entrá a *Actions → Android APK → Run workflow*.
3. Cuando termine, bajá el artefacto `aurora-player-apk`, descomprimilo e instalá `app-debug.apk`.

Si compilás por terminal con Gradle, usá **JDK 21** (Capacitor 8 no compila con 17 ni con 25).

## iOS (hace falta una Mac)
```
npm install
npx cap open ios
```
En Xcode 26 o más nuevo: elegí tu *Team* en *Signing & Capabilities* y dale ▶ con el iPhone conectado.
Con un Apple ID gratuito la app instalada dura 7 días; para publicarla en la App Store o usar TestFlight necesitás la cuenta de desarrollador paga.

## Qué cambia respecto al HTML
- Ícono de CD holográfico y pantalla de arranque oscura.
- Vibración al mantener apretado (háptica nativa).
- El color de la barra de estado cambia con el fondo elegido (Aurora, Negro, Blanco, Cromo).
- Pantalla vertical fija.
- El botón "Carpeta" se oculta (los móviles no lo soportan); se usa "Archivos".
- Música en segundo plano: iOS declara el modo de audio de fondo; en Android el WebView sigue activo al salir de la app.
- Los controles de la pantalla de bloqueo usan Media Session.

## Requisitos mínimos
iOS 16.4 o más · Android 7 (API 24) o más, con *Android System WebView* actualizado.

## Para probar primero en el celular
- Audio con la pantalla apagada (Android e iOS).
- Que los audios sigan ahí después de cerrar y reabrir la app.
- Si Android corta la música con la pantalla apagada, el paso siguiente es un servicio en primer plano con notificación de reproducción.

## Novedades v5
- Primer arranque: asistente para elegir fondo, color y primer disco. Sin discos ni audios de demostración.
- Disco "Biblioteca": todas tus canciones viven ahí; podés agregarlas a otros discos con el botón + o "Biblioteca".
- Sin límite de tamaño: manda el espacio libre del teléfono. Un WAV pesa ~10 MB por minuto; MP3/M4A unas 10 veces menos.
- Cambiar de disco no reproduce ni corta nada.
- Sin bordes en la interfaz.

## Actualizar la app
1. Subí el zip nuevo al repo (mismo nombre) para que GitHub genere un Release nuevo.
2. Bajá el APK e instalalo encima: los datos se conservan porque ahora la firma es fija.
   (El primer APK con esta firma requiere desinstalar la versión anterior una vez.)

## Spotify
No se pueden transferir playlists sin descargar: el audio de Spotify está protegido. Se importa la lista de temas (CSV/TXT/JSON/M3U) y se vincula con tus archivos locales por nombre.

## Novedades v6
- Los discos ahora son MiniDisc: carcasa translúcida, persiana metálica que se abre y disco con tu portada.
- Sin texto impreso en los discos. Aura holográfica opcional y fondo del disco (grafito, plata, negro) al apagarla.
- Inicio con botones fijos y un paso de tutorial (deslizar, tocar, mantener).
- Al volver al inicio no se precarga ninguna canción en el reproductor.
- Fondo cromo reactivo: el reflejo se mueve con el giro del celular o el dedo; el botón play es una esfera cromada.
- Bordes de la interfaz restaurados; la pantalla va de borde a borde.

## Novedades v7
- Vuelve el estuche de CD real (más detallado: marcos en las esquinas, bisagras, traba lateral) y la tapa se abre al abrir el disco.
- Disco estilo MiniDisc de color: elegís el color del disco y el color del vidrio del estuche. Aura holográfica opcional.
- Cromo igual al del Aurora Launcher: gris metálico suave que se mueve con el giro del celular.

## Novedades v8
- Fondo Aurora = glow desde arriba con color de fade a elección (Personalizar > General).
- Menú de personalización en pestañas: Disco / Música / General, con efectos plegados.

## Novedades v9
- Al tocar un disco, el estuche se abre y aparece el CD gigante a la izquierda con la lista a la derecha (Personalizar > General > Al abrir un disco: Disco gigante o Lista abajo).
- Fondo ambiente: la portada del disco (o su color) difuminada detrás de todo.

## Novedades v10
- Rendimiento: sin recorte/máscara en el disco que gira, barra de progreso a 4 Hz (antes 60), discos lejanos sin dibujarse, fondo ambiente con miniatura de 24 px.
- Fondo "Mi foto" (con oscurecer y difuminar), fade automático desde la portada, temporizador para apagar la música.
- PWA (manifest + service worker): se instala en iPhone/Android desde el navegador y funciona sin internet.
- Workflows de GitHub: pages.yml (publica la web) e ios.yml (IPA sin firmar para Sideloadly/AltStore).

## Novedades v11
- Sin temporizador de apagado.
- Formatos de disco: CD, vinilo y cassette (Ajustes > Disco).
- Modo glass (Ajustes > General), apagado por defecto para ir rápido.
- Widget Android (mantené apretada la pantalla de inicio > Widgets > Aurora Player). Sin widget en iOS.
- Más formatos de audio: mp3, wav, flac, m4a, aac, ogg, opus, aiff, wma, etc. (depende del dispositivo).
- Ajustes sin superposiciones y menos trabajo redundante.

## v12
- Widget Android corregido (el layout usaba una vista no permitida).
- Vinilo y cassette rediseñados: funda con celofán y marcas minimalistas, etiqueta mate con tu color; matiz, brillo y color siguen personalizables.

## v13
- Widget con la forma de tu formato (CD, vinilo o cassette), portada y brillo del color del álbum.
- Vinilo con brazo de tocadiscos que baja al reproducir.

## v14
- Widget con estilo tocadiscos (CD/vinilo, con brazo) o cassette oscuro estilo grabadora, con el color del álbum. Se sacó el brazo de la app.

## v15
- Nuevo logo (cubo cromado) en ícono de app, PWA y widget; versión PC en pantallas anchas; widget con fallback ante errores.

## v16
- Copia de seguridad: Ajustes > General > Exportar/Importar un archivo .aurora con discos, colores, portadas y canciones.

## v17
- Widget: los botones ahora abren la app si está cerrada y ejecutan la orden; si falla la sincronización, la app muestra un aviso "Widget: ...".

## v18
- Ajustes premium (menú arriba a la derecha): temas compartibles por enlace o código (solo estética), tipografías Retro/Utopía/Nothing, color Personalizado/Degradé/Plata/Oro, idioma ES/EN/PT.
- Álbumes: exportar e importar de a uno (.aurora); la copia completa queda aparte.
- Animaciones: el disco arranca y frena suave, resortes en botones, entradas escalonadas.

## v19
- Presentación: carrusel, cuadrícula (PC y celular) y walkman. Barra de PC con volumen y velocidad (normal/glass/walkman).
- Velocidad de reproducción (con o sin mantener el tono). Color de letras. Se quitaron los temas de fábrica y los modos plata/oro.
- Widget en forma de píldora con el color de acento y botones funcionales; botón "Probar widget" en Ajustes.
- Glass: se corrigió el panel de Ajustes y las hojas cerradas.

## v20
- **Notificación de reproducción ("nubecita")**: servicio nativo + MediaSession con portada, anterior/pausa/siguiente y controles en pantalla bloqueada. Android 13+ pide permiso de notificaciones la primera vez que suena algo. Se compila igual con GitHub Actions (sin Android Studio).
- Presentaciones nuevas: **Pila** y **Abanico**.
- **Desgaste del disco**: cuanto más escuchás un disco, más rayones finos aparecen (se completa a las 60 reproducciones).
- Exportar/importar ahora muestra el motivo exacto si falla.

## v21
- **Cromo real**: fondo de acero cepillado con botones biselados, barra "Cromo" y deslizadores metálicos.
- **Y2K**: fondo iridiscente con botones tipo gel, título cromado y tipografía Y2K.
- **Lista MP3**: sin discos; lista de playlists y, al abrir una, sus canciones abajo.
- **Stem**: reproductor tipo Stemplayer. Disco central (girá el dedo para avanzar o retroceder), segundos arriba a la derecha, tira de picos reales, tira de volumen y teclas anterior / pausa / siguiente.
- Discos, estuches y cajas con más detalle (surcos finos, reflejos tipo espejo, bordes).
- Los temas por link/código incluyen ahora fondo, barra, presentación y tipografía nuevos.

## v22
- Reproductores a pantalla completa: **Stem** (arreglado: cambia de álbum deslizando o con las flechas), **Monolito** (panel técnico blanco/rojo), **Nexo** (cyberpunk HUD con el color de acento) y **Reactor** (hardware naranja retro-futurista con perilla de volumen).
- **Botones 3D** (Ajustes > Tipografía): se inclinan con el celular, con brillo móvil.
- **Tapas realistas** (Ajustes > Tipografía): film del vinilo, lengüeta y polvo en el estuche del CD, aros del centro. Mantiene el estilo Nothing.
- Cromo líquido (SVG estático, sin costo en animación).
- Modo ahorro automático si el celular va justo en los primeros segundos de uso.

## v23
- **Arreglo importante**: el Stem usaba los mismos IDs (`stT`, `stPrev`) que el panel "Personalizar disco", y eso rompía los colores del disco y la vista previa. Ya no se pisan.
- Service worker: ahora el HTML se pide primero a la red, así las actualizaciones llegan en la primera recarga (en PC se quedaba con la versión vieja guardada).
- **Casete nuevo**: carcasa ahumada con tornillos, carretes con cinta enrollada, ventana, trapecio inferior con agujeros y cabezal.
- **Naked**: nuevo formato de disco (tornamesa transparente): plato con anillo estroboscópico dorado, etiqueta del color elegido, brazo dorado que baja sobre el disco al reproducir, perillas, vents y fader.
- **Protocolo**: reproductor cyberpunk (etiquetas con código de barras, anillo con retícula, perilla de volumen, tira de picos y pie gris con título).

## v24
- Eliminados: formato Naked y presentaciones Protocolo, Reactor, Nexo y Monolito (los datos guardados migran solos).
- "Modo disco realista" (Ajustes): CD con estuche, vinilo con funda y casete con capas renderizadas en 3D (Mitsuba) y sombreado de relieve; las imágenes se cargan solo si el modo está activo.

## v25
- Presentación **Casete**: panel metálico mate a pantalla completa con cassette AURORA y 5 botones (play/pausa, siguiente, atrás, repetir, lista de playlists y canciones).

## v26
- Presentación **Cyberpunk** (metal cepillado, negro y rojo carmesí). Casete: capa 3D en el cassette y la barra superior ya no queda tapada (se pueden cambiar los modos).

## v27
- Cyberpunk: sin barra horizontal; anillo de progreso (tocable) y 84 barras radiales reactivas al audio alrededor del disco.

## v28
- Cyberpunk rehecho: estética Nothing maximalista (vidrio oscuro, malla de puntos, fuente puntillada), neón suave con el color de interfaz del usuario, anillo de progreso con barras reactivas, tira de nivel y volumen.

## v29
- Cyberpunk maximalista: módulos internos, rejillas, texto técnico, CE/UK/CA, tornillos, cable USB, trazas y ticks en el disco.

## v30
- Cassette 3D real (render con geometria: carcasa biselada, tornillos, ventana, agujeros). Se usa en el modo Casete y en el formato casete con Modo disco realista. Cyberpunk retirado del selector.

## v31
- Modo Casete rehecho calcando la referencia: aluminio claro, panel negro con LCD y botones metalicos, ventana ovalada con cassette 3D claro.

## v33
- Modo Cyberpunk rehecho (estética Nothing maximalista): plato con espiral, anillo de luz de progreso en el color de acento, 96 barras reactivas al audio, título en matriz de puntos, selector de álbumes ◀ ▶, teclas atrás/repetir/play/lista/siguiente, tira VU y volumen.

## v34
- Botones 3D rehechos: cuerpo negro brillante con bisel cromo iridiscente (variante vidrio claro en fondos blancos/cromo), en barra superior, controles del reproductor y Cyberpunk.

## v35
- Botones 3D premium solo con "Botones 3D" activo; los botones normales vuelven a su estilo original.

## v36
- Glass arreglado: el estilo del modo choca con la clase del estuche de CD (.glass), lo que pintaba reflejos y fondo sobre toda la app. Renombrado a .gls. En Android y modo rendimiento se desactiva backdrop-filter y se usa vidrio con degradados.
- Nuevo modo Sampler: 9 pads, chop por golpes (AUTO) o en 9 cortes iguales, chop en vivo (REC + PREV), samples distintos por pad, pitch/tone/decay/vol, modos ONE/GATE/LOOP, arrastrar inicio/fin sobre la onda.

## v37
- Sampler rehecho con estética MPC: pads en orden de lectura (1 arriba-izquierda), AUTO robusto dentro de la región, MARK (corte en vivo) con fines automáticos, SAVE: guardar a Biblioteca, descargar .wav/.zip, captura de lo que tocas, kits, fader master.
- Nuevo modo Futuristic Player (círculo grande, título, 4 botones).
- Optimización: analizador de audio sólo en modos reactivos, 30 fps en Android para modos reactivos, menos trabajo por frame, temporizadores sólo cuando hacen falta.
- AuroraFiles: createFile acepta mime.

## v38
- Futuristic Player rehecho con la estética de las fotos: losa blanca brillante con placa negra y lenguas acanaladas (fondos oscuros) o losa negra mate con cavidades orgánicas (fondos claros). Estela rítmica líquida alrededor del disco con rastros que reaccionan al audio.

## v39
- Futuristic Player: vuelve el diseño abierto (disco grande, anillo, nombre y 4 botones) con formas orgánicas "englobadas" detrás. El estilo "Losa" (v38) sigue disponible.
- Personalización individual por modo (Cyberpunk, Futuristic, Stemplayer, Casete, Sampler): mantené apretada la pantalla dentro del modo → colores propios de ese modo (Casete: parte superior y cuerpo; Cyberpunk/Futuristic: tono blanco), con "Restablecer".
- PC: el carrusel y los discos ocupan el área disponible.

## Instalar en iPhone (desde GitHub)
**Opción A — Web app (recomendada, sin Mac ni cuenta de desarrollador):**
1. Subí este proyecto a un repo de GitHub (rama `main`).
2. Repo → Settings → Pages → Source: **GitHub Actions**.
3. El workflow `Pages` publica `www/` en `https://TU-USUARIO.github.io/NOMBRE-REPO/`.
4. En el iPhone abrí ese enlace en **Safari** → Compartir → **Añadir a pantalla de inicio**. Funciona offline.

**Opción B — IPA sin firmar:** Actions → *iOS IPA (sin firmar)* → Run workflow → descargá `aurora-player-ios`. Se instala con AltStore/Sideloadly (Apple ID gratuito, renovar cada 7 días).

## v40
- Futuristic Player: se restaura el diseño anterior (v37: disco grande, halo, anillo, nombre y 4 botones).
- PC (pantallas ≥1000px): en los modos Stemplayer, Casete, Cyberpunk, Futuristic y Sampler aparecen paneles a los costados: título grande a la izquierda y cola de canciones clickeable a la derecha.
