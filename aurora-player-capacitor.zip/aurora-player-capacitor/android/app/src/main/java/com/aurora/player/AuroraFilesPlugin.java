package com.aurora.player;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;

/** Guarda la copia de seguridad (.aurora) en el lugar que elija el usuario. */
@CapacitorPlugin(name = "AuroraFiles")
public class AuroraFilesPlugin extends Plugin {
    private OutputStream out;

    @PluginMethod
    public void createFile(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(call.getString("mime", "application/octet-stream"));
        i.putExtra(Intent.EXTRA_TITLE, call.getString("name", "aurora.aurora"));
        startActivityForResult(call, i, "createResult");
    }

    @ActivityCallback
    private void createResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        try {
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                Uri uri = result.getData().getData();
                out = getContext().getContentResolver().openOutputStream(uri, "w");
                call.resolve();
            } else {
                call.reject("cancel");
            }
        } catch (Exception e) {
            call.reject("error");
        }
    }

    @PluginMethod
    public void write(PluginCall call) {
        try {
            out.write(Base64.decode(call.getString("data", ""), Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("error");
        }
    }

    @PluginMethod
    public void close(PluginCall call) {
        try {
            if (out != null) out.close();
        } catch (Exception e) {
        }
        out = null;
        call.resolve();
    }
}
