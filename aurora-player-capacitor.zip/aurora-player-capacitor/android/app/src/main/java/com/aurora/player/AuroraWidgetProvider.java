package com.aurora.player;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.Base64;
import android.widget.RemoteViews;

public class AuroraWidgetProvider extends AppWidgetProvider {
    static final String PREFS = "aurora_widget";
    static final String A_PLAY = "com.aurora.player.WIDGET_PLAY";
    static final String A_NEXT = "com.aurora.player.WIDGET_NEXT";
    static final String A_PREV = "com.aurora.player.WIDGET_PREV";
    
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        RemoteViews v = build(c);
        for (int id : ids) m.updateAppWidget(id, v);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (A_PLAY.equals(a) || A_NEXT.equals(a) || A_PREV.equals(a)) {
            if (!AuroraWidgetPlugin.dispatch(a)) {
                Intent open = new Intent(c, MainActivity.class);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                try { c.startActivity(open); } catch (Exception e) { }
            }
            return;
        }
        super.onReceive(c, i);
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, AuroraWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews v = build(c);
        for (int id : ids) m.updateAppWidget(id, v);
    }

    private static PendingIntent btn(Context c, String action, int code) {
        Intent i = new Intent(c, AuroraWidgetActionActivity.class).setAction(action);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static RemoteViews build(Context c) {
        try {
            return buildFull(c);
        } catch (Throwable t) {
            android.util.Log.e("AuroraWidget", "build failed", t);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.aurora_widget);
            rv.setOnClickPendingIntent(R.id.w_play, btn(c, A_PLAY, 1));
            rv.setOnClickPendingIntent(R.id.w_next, btn(c, A_NEXT, 2));
            rv.setOnClickPendingIntent(R.id.w_prev, btn(c, A_PREV, 3));
            return rv;
        }
    }

    static RemoteViews buildFull(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, 0);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.aurora_widget);
        int acc;
        try {
            acc = Color.parseColor(p.getString("accent", "#8b8cff"));
        } catch (Exception e) {
            acc = 0xFF8B8CFF;
        }
        double lum = 0.299 * Color.red(acc) + 0.587 * Color.green(acc) + 0.114 * Color.blue(acc);
        int tc = lum > 150 ? 0xFF111114 : 0xFFFFFFFF;
        int tc2 = (tc & 0x00FFFFFF) | 0xB3000000;
        rv.setInt(R.id.w_bg, "setColorFilter", acc | 0xFF000000);
        rv.setTextViewText(R.id.w_title, p.getString("title", "Aurora Player"));
        rv.setTextViewText(R.id.w_artist, p.getString("artist", "Abrí la app para empezar"));
        rv.setTextColor(R.id.w_title, tc);
        rv.setTextColor(R.id.w_artist, tc2);
        rv.setImageViewResource(R.id.w_play, p.getBoolean("playing", false) ? R.drawable.w_ic_pause : R.drawable.w_ic_play);
        rv.setInt(R.id.w_play, "setColorFilter", tc);
        rv.setInt(R.id.w_prev, "setColorFilter", tc);
        rv.setInt(R.id.w_next, "setColorFilter", tc);
        try {
            rv.setImageViewBitmap(R.id.w_cover, cover(p));
        } catch (Throwable t) {
            android.util.Log.e("AuroraWidget", "cover failed", t);
        }
        rv.setOnClickPendingIntent(R.id.w_play, btn(c, A_PLAY, 1));
        rv.setOnClickPendingIntent(R.id.w_next, btn(c, A_NEXT, 2));
        rv.setOnClickPendingIntent(R.id.w_prev, btn(c, A_PREV, 3));
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return rv;
    }

    private static Paint P(int c) {
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setColor(c);
        return q;
    }

    private static int mix(int a, int b, float t) {
        return Color.rgb((int) (Color.red(a) * (1 - t) + Color.red(b) * t), (int) (Color.green(a) * (1 - t) + Color.green(b) * t), (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t));
    }

    /** Dibuja un círculo con la portada (o degradado) dentro. */
    private static void disc(Canvas cv, Bitmap src, float cx, float cy, float rad, int col) {
        Bitmap t = Bitmap.createBitmap((int) (rad * 2), (int) (rad * 2), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(t);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        c.drawCircle(rad, rad, rad, pt);
        pt.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        if (src != null) {
            float s = Math.max(rad * 2 / src.getWidth(), rad * 2 / src.getHeight());
            Matrix m = new Matrix();
            m.postScale(s, s);
            m.postTranslate((rad * 2 - src.getWidth() * s) / 2f, (rad * 2 - src.getHeight() * s) / 2f);
            c.drawBitmap(src, m, pt);
        } else {
            pt.setShader(new LinearGradient(0, 0, rad * 2, rad * 2, mix(col, Color.WHITE, .25f), mix(col, Color.BLACK, .45f), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, rad * 2, rad * 2, pt);
        }
        cv.drawBitmap(t, cx - rad, cy - rad, null);
    }

    private static Bitmap cover(SharedPreferences p) {
        Bitmap src = null;
        String b64 = p.getString("cover", "");
        if (b64 != null && b64.length() > 0) {
            try {
                byte[] d = Base64.decode(b64, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(d, 0, d.length);
            } catch (Exception e) {
                src = null;
            }
        }
        int col;
        try {
            col = Color.parseColor(p.getString("color", "#8b8cff"));
        } catch (Exception e) {
            col = 0xFF8B8CFF;
        }
        String fmt = p.getString("fmt", "cd");
        final int N = 360;
        Bitmap out = Bitmap.createBitmap(N, N, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        float cx = N / 2f, cy = N / 2f;
        if ("cassette".equals(fmt)) {
            RectF body = new RectF(6, 78, N - 6, N - 78);
            cv.drawRoundRect(body, 22, 22, P(0xFF1A1C22));
            Paint st = P(0x66FFFFFF);
            st.setStyle(Paint.Style.STROKE);
            st.setStrokeWidth(3);
            cv.drawRoundRect(body, 22, 22, st);
            RectF lab = new RectF(24, 92, N - 24, 168);
            cv.drawRoundRect(lab, 10, 10, P(mix(col, Color.BLACK, .2f)));
            if (src != null) {
                Bitmap tmp = Bitmap.createBitmap((int) lab.width(), (int) lab.height(), Bitmap.Config.ARGB_8888);
                Canvas tc = new Canvas(tmp);
                Paint tq = new Paint(Paint.ANTI_ALIAS_FLAG);
                tc.drawRoundRect(new RectF(0, 0, lab.width(), lab.height()), 10, 10, tq);
                tq.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                float s = Math.max(lab.width() / src.getWidth(), lab.height() / src.getHeight());
                Matrix m = new Matrix();
                m.postScale(s, s);
                m.postTranslate((lab.width() - src.getWidth() * s) / 2f, (lab.height() - src.getHeight() * s) / 2f);
                tc.drawBitmap(src, m, tq);
                cv.drawBitmap(tmp, lab.left, lab.top, null);
            }
            RectF win = new RectF(70, 112, N - 70, 176);
            cv.drawRoundRect(win, 32, 32, P(0xF0080A0E));
            for (int k = -1; k <= 1; k += 2) {
                float rx = cx + k * 52;
                cv.drawCircle(rx, 144, 27, P(mix(col, Color.BLACK, .55f)));
                cv.drawCircle(rx, 144, 17, P(0xFFD9DCE2));
                cv.drawCircle(rx, 144, 9, P(0xFF16171B));
            }
            Path tr = new Path();
            tr.moveTo(98, N - 78);
            tr.lineTo(116, 212);
            tr.lineTo(N - 116, 212);
            tr.lineTo(N - 98, N - 78);
            tr.close();
            cv.drawPath(tr, P(0xB3101216));
            return out;
        }
        float rad = N * 0.47f;
        boolean vin = "vinilo".equals(fmt);
        if (vin) {
            cv.drawCircle(cx, cy, rad, P(0xFF0B0B0E));
            Paint g = P(0x26FFFFFF);
            g.setStyle(Paint.Style.STROKE);
            g.setStrokeWidth(1.5f);
            for (float q = rad * 0.45f; q < rad * 0.97f; q += 7) cv.drawCircle(cx, cy, q, g);
            disc(cv, src, cx, cy, rad * 0.42f, col);
        } else {
            disc(cv, src, cx, cy, rad, col);
            Paint rim = P(0x66FFFFFF);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(3);
            cv.drawCircle(cx, cy, rad, rim);
            cv.drawCircle(cx, cy, rad * 0.2f, P(0x99000000));
        }
        cv.drawCircle(cx, cy, 11, P(0xFFE9EBEF));
        cv.drawCircle(cx, cy, 5, P(0xFF0B0B0E));
        Paint sh = new Paint(Paint.ANTI_ALIAS_FLAG);
        sh.setShader(new LinearGradient(cx - rad, cy - rad, cx + rad, cy + rad, new int[]{0x00FFFFFF, 0x33FFFFFF, 0x00FFFFFF}, new float[]{.3f, .45f, .6f}, Shader.TileMode.CLAMP));
        cv.drawCircle(cx, cy, rad, sh);
        return out;
    }
}
