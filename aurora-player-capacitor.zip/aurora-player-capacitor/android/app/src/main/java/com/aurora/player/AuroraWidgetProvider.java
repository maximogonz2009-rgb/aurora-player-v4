package com.aurora.player;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.Base64;
import android.widget.RemoteViews;

public class AuroraWidgetProvider extends AppWidgetProvider {
    static final String PREFS = "aurora_widget";
    static final String A_PLAY = "com.aurora.player.WIDGET_PLAY";
    static final String A_NEXT = "com.aurora.player.WIDGET_NEXT";
    static final String A_PREV = "com.aurora.player.WIDGET_PREV";
    private static final int SIZE = 480;

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        RemoteViews v = build(c);
        for (int id : ids) m.updateAppWidget(id, v);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (A_PLAY.equals(a) || A_NEXT.equals(a) || A_PREV.equals(a)) {
            if (!AuroraWidgetPlugin.dispatch(a)) {
                Intent open = new Intent(c, MainActivity.class);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                try { c.startActivity(open); } catch (Exception e) { }
            }
            return;
        }
        super.onReceive(c, i);
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, AuroraWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews v = build(c);
        for (int id : ids) m.updateAppWidget(id, v);
    }

    private static PendingIntent btn(Context c, String action, int code) {
        Intent i = new Intent(c, AuroraWidgetProvider.class).setAction(action);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static RemoteViews build(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, 0);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.aurora_widget);
        rv.setTextViewText(R.id.w_title, p.getString("title", "Aurora Player"));
        rv.setTextViewText(R.id.w_artist, p.getString("artist", "Abrí la app para empezar"));
        rv.setImageViewResource(R.id.w_play, p.getBoolean("playing", false) ? R.drawable.w_ic_pause : R.drawable.w_ic_play);
        rv.setImageViewBitmap(R.id.w_cover, cover(p));
        rv.setOnClickPendingIntent(R.id.w_play, btn(c, A_PLAY, 1));
        rv.setOnClickPendingIntent(R.id.w_next, btn(c, A_NEXT, 2));
        rv.setOnClickPendingIntent(R.id.w_prev, btn(c, A_PREV, 3));
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return rv;
    }

    private static Bitmap cover(SharedPreferences p) {
        Bitmap src = null;
        String b64 = p.getString("cover", "");
        if (b64 != null && b64.length() > 0) {
            try {
                byte[] d = Base64.decode(b64, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(d, 0, d.length);
            } catch (Exception e) {
                src = null;
            }
        }
        Bitmap out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = SIZE * 0.1f;
        cv.drawRoundRect(new RectF(0, 0, SIZE, SIZE), r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        if (src != null) {
            float s = Math.max((float) SIZE / src.getWidth(), (float) SIZE / src.getHeight());
            Matrix m = new Matrix();
            m.postScale(s, s);
            m.postTranslate((SIZE - src.getWidth() * s) / 2f, (SIZE - src.getHeight() * s) / 2f);
            cv.drawBitmap(src, m, paint);
        } else {
            int col;
            try {
                col = Color.parseColor(p.getString("color", "#8b8cff"));
            } catch (Exception e) {
                col = 0xFF8B8CFF;
            }
            int dark = Color.rgb((int) (Color.red(col) * 0.35f), (int) (Color.green(col) * 0.35f), (int) (Color.blue(col) * 0.35f));
            paint.setShader(new LinearGradient(0, 0, SIZE, SIZE, col, dark, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, SIZE, SIZE, paint);
        }
        return out;
    }
}
