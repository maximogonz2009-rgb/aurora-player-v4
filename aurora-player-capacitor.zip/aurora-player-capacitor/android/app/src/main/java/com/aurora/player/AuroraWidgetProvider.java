package com.aurora.player;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.Base64;
import android.widget.RemoteViews;

public class AuroraWidgetProvider extends AppWidgetProvider {
    static final String PREFS = "aurora_widget";
    static final String A_PLAY = "com.aurora.player.WIDGET_PLAY";
    static final String A_NEXT = "com.aurora.player.WIDGET_NEXT";
    static final String A_PREV = "com.aurora.player.WIDGET_PREV";
    
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        RemoteViews v = build(c);
        for (int id : ids) m.updateAppWidget(id, v);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (A_PLAY.equals(a) || A_NEXT.equals(a) || A_PREV.equals(a)) {
            if (!AuroraWidgetPlugin.dispatch(a)) {
                Intent open = new Intent(c, MainActivity.class);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                try { c.startActivity(open); } catch (Exception e) { }
            }
            return;
        }
        super.onReceive(c, i);
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, AuroraWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews v = build(c);
        for (int id : ids) m.updateAppWidget(id, v);
    }

    private static PendingIntent btn(Context c, String action, int code) {
        Intent i = new Intent(c, AuroraWidgetActionActivity.class).setAction(action);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static RemoteViews build(Context c) {
        try {
            return buildFull(c);
        } catch (Throwable t) {
            android.util.Log.e("AuroraWidget", "build failed", t);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.aurora_widget);
            rv.setOnClickPendingIntent(R.id.w_play, btn(c, A_PLAY, 1));
            rv.setOnClickPendingIntent(R.id.w_next, btn(c, A_NEXT, 2));
            rv.setOnClickPendingIntent(R.id.w_prev, btn(c, A_PREV, 3));
            return rv;
        }
    }

    static RemoteViews buildFull(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, 0);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.aurora_widget);
        rv.setTextViewText(R.id.w_title, p.getString("title", "Aurora Player"));
        rv.setTextViewText(R.id.w_artist, p.getString("artist", "Abrí la app para empezar"));
        rv.setImageViewResource(R.id.w_play, p.getBoolean("playing", false) ? R.drawable.w_ic_pause : R.drawable.w_ic_play);
        try {
            rv.setImageViewBitmap(R.id.w_cover, cover(p));
        } catch (Throwable t) {
            android.util.Log.e("AuroraWidget", "cover failed", t);
        }
        rv.setOnClickPendingIntent(R.id.w_play, btn(c, A_PLAY, 1));
        rv.setOnClickPendingIntent(R.id.w_next, btn(c, A_NEXT, 2));
        rv.setOnClickPendingIntent(R.id.w_prev, btn(c, A_PREV, 3));
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return rv;
    }

    private static Paint P(int c) {
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setColor(c);
        return q;
    }

    private static int mix(int a, int b, float t) {
        return Color.rgb((int) (Color.red(a) * (1 - t) + Color.red(b) * t), (int) (Color.green(a) * (1 - t) + Color.green(b) * t), (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t));
    }

    /** Dibuja un círculo con la portada (o degradado) dentro. */
    private static void disc(Canvas cv, Bitmap src, float cx, float cy, float rad, int col) {
        Bitmap t = Bitmap.createBitmap((int) (rad * 2), (int) (rad * 2), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(t);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        c.drawCircle(rad, rad, rad, pt);
        pt.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        if (src != null) {
            float s = Math.max(rad * 2 / src.getWidth(), rad * 2 / src.getHeight());
            Matrix m = new Matrix();
            m.postScale(s, s);
            m.postTranslate((rad * 2 - src.getWidth() * s) / 2f, (rad * 2 - src.getHeight() * s) / 2f);
            c.drawBitmap(src, m, pt);
        } else {
            pt.setShader(new LinearGradient(0, 0, rad * 2, rad * 2, mix(col, Color.WHITE, .25f), mix(col, Color.BLACK, .45f), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, rad * 2, rad * 2, pt);
        }
        cv.drawBitmap(t, cx - rad, cy - rad, null);
    }

    private static Bitmap cover(SharedPreferences p) {
        Bitmap src = null;
        String b64 = p.getString("cover", "");
        if (b64 != null && b64.length() > 0) {
            try {
                byte[] d = Base64.decode(b64, Base64.DEFAULT);
                src = BitmapFactory.decodeByteArray(d, 0, d.length);
            } catch (Exception e) {
                src = null;
            }
        }
        int col;
        try {
            col = Color.parseColor(p.getString("color", "#8b8cff"));
        } catch (Exception e) {
            col = 0xFF8B8CFF;
        }
        String fmt = p.getString("fmt", "cd");
        boolean playing = p.getBoolean("playing", false);
        final int W = 640, H = 512;
        Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        // chasis oscuro con un leve brillo del color del álbum
        Bitmap bg = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas bc = new Canvas(bg);
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bc.drawRoundRect(new RectF(0, 0, W, H), 60, 60, bp);
        bp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        bp.setShader(new LinearGradient(0, 0, W, H, mix(0xFF26272D, col, .10f), 0xFF0E0F12, Shader.TileMode.CLAMP));
        bc.drawRect(0, 0, W, H, bp);
        cv.drawBitmap(bg, 0, 0, null);
        Paint edge = P(0x22FFFFFF);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(3);
        cv.drawRoundRect(new RectF(2, 2, W - 2, H - 2), 58, 58, edge);

        if ("cassette".equals(fmt)) {
            Paint scr = P(0xFF3A3C44);
            float[][] sc = {{44, 44}, {W - 44, 44}, {44, H - 44}, {W - 44, H - 44}};
            for (float[] q : sc) {
                cv.drawCircle(q[0], q[1], 17, scr);
                Paint x = P(0xFF101114);
                x.setStrokeWidth(5);
                cv.drawLine(q[0] - 9, q[1], q[0] + 9, q[1], x);
                cv.drawLine(q[0], q[1] - 9, q[0], q[1] + 9, x);
            }
            // ventana central con carretes
            RectF win = new RectF(95, 70, W - 95, 330);
            cv.drawRoundRect(win, 26, 26, P(0xFF08090B));
            Paint wr = P(0x33FFFFFF);
            wr.setStyle(Paint.Style.STROKE);
            wr.setStrokeWidth(3);
            cv.drawRoundRect(win, 26, 26, wr);
            float ry = win.centerY();
            for (int k = -1; k <= 1; k += 2) {
                float rx = W / 2f + k * 130;
                float tapeR = k < 0 ? 112 : 84;
                Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
                tp.setShader(new android.graphics.RadialGradient(rx, ry, tapeR, mix(col, Color.BLACK, .35f), mix(col, Color.BLACK, .75f), Shader.TileMode.CLAMP));
                cv.drawCircle(rx, ry, tapeR, tp);
                cv.drawCircle(rx, ry, 56, P(0xFFD9DCE2));
                cv.drawCircle(rx, ry, 56, edge);
                cv.drawCircle(rx, ry, 36, P(0xFF16171B));
                Paint tooth = P(0xFFD9DCE2);
                for (int a = 0; a < 6; a++) {
                    double t = Math.toRadians(a * 60);
                    cv.drawCircle((float) (rx + Math.cos(t) * 30), (float) (ry + Math.sin(t) * 30), 7, tooth);
                }
                cv.drawCircle(rx, ry, 12, P(0xFF2A2C32));
            }
            // etiqueta con portada o color
            RectF lab = new RectF(150, 350, W - 150, 440);
            cv.drawRoundRect(lab, 14, 14, P(mix(col, Color.BLACK, .25f)));
            if (src != null) {
                Bitmap tmp = Bitmap.createBitmap((int) lab.width(), (int) lab.height(), Bitmap.Config.ARGB_8888);
                Canvas tc = new Canvas(tmp);
                Paint tq = new Paint(Paint.ANTI_ALIAS_FLAG);
                tc.drawRoundRect(new RectF(0, 0, lab.width(), lab.height()), 14, 14, tq);
                tq.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                float s = Math.max(lab.width() / src.getWidth(), lab.height() / src.getHeight());
                Matrix m = new Matrix();
                m.postScale(s, s);
                m.postTranslate((lab.width() - src.getWidth() * s) / 2f, (lab.height() - src.getHeight() * s) / 2f);
                tc.drawBitmap(src, m, tq);
                cv.drawBitmap(tmp, lab.left, lab.top, null);
            }
            return out;
        }

        // tocadiscos (CD y vinilo)
        float cx = 290, cy = 262, plat = 218;
        cv.drawCircle(cx, cy, plat + 14, P(mix(0xFF050507, col, .12f)));
        cv.drawCircle(cx, cy, plat, P(0xFF0B0B0E));
        Paint ring = P(0xFFFFFFFF);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(6);
        ring.setColor(mix(0xFFFFFFFF, col, .3f));
        cv.drawArc(new RectF(cx - plat - 6, cy - plat - 6, cx + plat + 6, cy + plat + 6), -90, playing ? 270 : 360, false, ring);
        boolean vin = "vinilo".equals(fmt);
        float rad = plat - 22;
        disc(cv, src, cx, cy, rad, col);
        if (vin) {
            Paint g = P(0x26000000);
            g.setStyle(Paint.Style.STROKE);
            g.setStrokeWidth(2);
            for (float q = rad * 0.28f; q < rad; q += 9) cv.drawCircle(cx, cy, q, g);
            Paint lt = P(0x18FFFFFF);
            lt.setStyle(Paint.Style.STROKE);
            lt.setStrokeWidth(2);
            for (float q = rad * 0.30f; q < rad; q += 18) cv.drawCircle(cx, cy, q, lt);
        } else {
            Paint rim = P(0x66FFFFFF);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(4);
            cv.drawCircle(cx, cy, rad, rim);
            cv.drawCircle(cx, cy, rad * 0.2f, P(0x99000000));
            cv.drawCircle(cx, cy, rad * 0.2f, rim);
        }
        cv.drawCircle(cx, cy, 14, P(0xFFE9EBEF));
        cv.drawCircle(cx, cy, 6, P(0xFF0B0B0E));
        Paint sh = new Paint(Paint.ANTI_ALIAS_FLAG);
        sh.setShader(new LinearGradient(cx - rad, cy - rad, cx + rad, cy + rad, new int[]{0x00FFFFFF, 0x33FFFFFF, 0x00FFFFFF}, new float[]{.3f, .45f, .6f}, Shader.TileMode.CLAMP));
        cv.drawCircle(cx, cy, rad, sh);
        // brazo
        float px = 574, py = 92;
        cv.drawCircle(px, py, 44, P(0xFF2B2D33));
        cv.drawCircle(px, py, 44, edge);
        cv.save();
        cv.rotate(playing ? 17 : -3, px, py);
        Paint arm = P(0xFFC9CED8);
        arm.setStrokeWidth(11);
        arm.setStrokeCap(Paint.Cap.ROUND);
        cv.drawLine(px, py, px, py + 285, arm);
        cv.drawCircle(px, py, 24, P(0xFF4A4D55));
        cv.drawRoundRect(new RectF(px - 17, py + 262, px + 17, py + 322), 8, 8, P(0xFF20232A));
        cv.restore();
        return out;
    }
}
